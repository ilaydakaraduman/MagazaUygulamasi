#include <stdio.h>
#include <stdlib.h>

FILE *_dosya;
int musteri_Id; //musterilerin id arttirmk icin taanimli
int urunFonkCalis=0;  //array kontrolu
struct urun {         //struct : Birbirleriyle ili�kili degiskenlerin, bir isim alt�nda toplanmasini saglar
    	char urunId[10];
    	int urunAdet;
     	char urunAd[50];
 		int urunKategori; //urun structu urun ekleme,goruntuleme islemleri icin
		int urunFiyat;
		
}urun[100]; //total urun miktari 100 belirlendigi icin tum bu ozellikleri kapsayan array tanimladik
struct satis {
    	char urunId[10];
    	int musteriId;
     	char tarih[20];  //toplam satis miktarini goruntulemek icin
 		int adet;
 		int fiyat;

		
}satislar[100];
struct musteriler{
		char musteriAd[20];
		char musteriSoyad[20];   //musteri eklemek icin
		char musteriNo[18];
		int musteriId;
		
		
}musteriler[100];
struct SuperMarket{
		char Supermarketadi [1][30];
		char magazalar [15][50];
		char Kitalar [3][50];
		char Sehirler [3][50];   //mainte olusturmak uzere supermarket zinciri tarzinda bir struct icindeki elemanlarin 2 li array olusturulma sebebi,
		char Turler [5][50];      // bir supermarketin birden fazla kita sehir tanimlanmasi istendigi icin 1.array kac tane oldugunu 2.si her birinin max boyutunu temsil ediyor
		char Ulkeler [5][50];
		char Calisanlar [4][50];		
		
}SuperMarket;
int menu(){
	system("CLS");
printf(" \t \t****************************************************\n");
printf(" \t \t        -BILGEN SUPERMARKETE HOSGELDINIZ-           \n");
printf(" \t \t*              MUSTERI EKLEMEK ICIN             {1}*\n");
printf(" \t \t*           MUSTERI GORUNTULEMEK ICIN           {2}*\n");
printf(" \t \t*               URUN EKLEMEK ICIN               {3}*\n");
printf(" \t \t*            URUN GORUNTULEMEK ICIN             {4}*\n");
printf(" \t \t*             SATIS YAPMAK  ICIN                {5}*\n");   //menu kismi fonksiyon haline getirip mainde cagiriliyor
printf(" \t \t*        TOPLAM SATIS GORUNTULEMEK ICIN         {6}*\n");
printf(" \t \t*                 CIKMAK ICIN                   {0}*\n");
printf(" \t \t****************************************************\n");
int menuSecim;

return menuSecim;
}
void musteriEkle() {  //case1 musteri ekleme islemi
	FILE *_dosya;
	if((_dosya=fopen("musterikayit.txt","a+")) == NULL) {   //dosya islemlerinde fopen dosya i�inde islem yapmak icin kullanilir a+ ise hem olusturma,okuma,yazma her islem yapilabilir
		printf("Dosya olusturulamadi");
	}else {
		int i=0;
	

		

				while( !feof(_dosya) ){   //dosya tamamen okunadugunda while sona erir
			
 				fscanf(_dosya,"%s%s%s%d",musteriler[i].musteriAd,musteriler[i].musteriSoyad,musteriler[i].musteriNo, &musteriler[i].musteriId); //dosyadan veri okuma
 					if(musteriler[i].musteriId ==0) {   //dosya icerisindeki bilgileri alir ve bittiginde break(durdurma)saglanir
					break;
				}
 				musteri_Id = musteriler[i].musteriId;
				i++;
			 }
				 
				printf(" \t-Adiniz: ");
				scanf("%s",musteriler[i].musteriAd);
				printf("\n \t-Soyadiniz:  ");
				scanf("%s",musteriler[i].musteriSoyad);
				printf("\n \t-Telefon no:  ");                      //console dan bilgiler alinir
				scanf("%s",musteriler[i].musteriNo);
				musteriler[i].musteriId= musteri_Id+1;  //her musteri eklendiginde otomatik 1 arttirmak icin

				fprintf(_dosya,"%s %s %s %d\n",musteriler[i].musteriAd,musteriler[i].musteriSoyad,musteriler[i].musteriNo, musteriler[i].musteriId);  //acik dosya uzerine  yazdirma
				musteriGoruntule();      //totaldeki butun musterileri cagirmak icin
			fclose(_dosya);         //fopenlanan her dosya kapatilmalidir
	}
}

void musteriGoruntule() { //case 2 ekstadan urun goruntulenmek istenirse
		FILE *_dosya;
		if((_dosya=fopen("musterikayit.txt","r+")) == NULL) {
		printf("\nDosya olusturulamadi\n");
	}else {
		int i=0;
		
			printf("\n \t | %-10s   | %-14s   %-12s | \n", "MUSTERI ID" ,"   AD ", "SOYAD" );
			printf("\t ************************************************ \n");
				while( !feof(_dosya) ){
			
 				fscanf(_dosya,"%s%s%s%d",musteriler[i].musteriAd,musteriler[i].musteriSoyad,musteriler[i].musteriNo, &musteriler[i].musteriId);
 			
 				
 					if(musteriler[i].musteriId ==0) {
					break;					
			 	}
				printf(" \t |      %-7d | %-14s   %-12s | \n",musteriler[i].musteriId ,musteriler[i].musteriAd,musteriler[i].musteriSoyad);
				printf("\t ------------------------------------------------ \n");
				i++;
			 }	
			 	
			fclose(_dosya);
	}
}
    void UrunEkle(){//urun kayitlar buras� //case3
		FILE *_dosya;
		if((_dosya=fopen("urunKayit.txt","a+")) == NULL){
		printf("Dosya olusturulamadi");
		
		}
		else{
			int i=0;
			int flag = 0;  //bool amacli urunun olup olmamasini kotrol etmek icin 
			char urunId[10];  //kullanicidan gelen veriyi gecici tutmak icin olusuruldu
		
			while( !feof(_dosya) ){
			
 				fscanf(_dosya,"%s%s%d%d%d",urun[i].urunId, urun[i].urunAd, &urun[i].urunKategori, &urun[i].urunAdet,&urun[i].urunFiyat);
 					if(urun[i].urunKategori== 0) {
					break;
					urunFonkCalis =1;   //urunun arrayde tekrar edip etmemesini saglamak amaciyla 
					}
				i++;
			 }
				printf("\n \t-Urun Idsi : ");   //urun icin consoledan veri alma
				scanf("%s",urunId);
					if(urunBul(urunId)) {  //hafizada parametredeki urun varligini kontrol eder var ise 1 ,yoksa 0 dondurur
						flag = 1;
					}
				if(flag == 0) {  //yeni urun eklemek icin
				strcpy(urun[i].urunId,urunId);
				printf("\n \t-Urun adi :  ");
				scanf("%s",urun[i].urunAd);
				kategori: 
				printf("\n \t-Urunun Kategori numarasi : \n \t giyim(1) \n \t elektronik(2) \n \t mobilya(3) \n \t temizlik(4) \n \t gida(5) :  ");
				scanf("%d",&urun[i].urunKategori);
				if(urun[i].urunKategori<6 && urun[i].urunKategori>0){  //odevde verilen kategori disinda eklenmek istenirse engeller
				printf("\n \t-Urunden kac adet bulunmakta :  ");
				scanf("%d",&urun[i].urunAdet);
				printf("\n \t-Urunun fiyati :  ");
				scanf("%d",&urun[i].urunFiyat);	
				fprintf(_dosya,"%s %s %d %d %d\n",urun[i].urunId, urun[i].urunAd, urun[i].urunKategori, urun[i].urunAdet,urun[i].urunFiyat);
				fclose(_dosya);		
				}
				else{
					printf(" \tSecmis oldugunuz kategori numarasi bulunmamaktadir yeniden deneyiniz... \n ");
					goto kategori;
				}
				}	
				else if(flag == 1) {  //var olan urunun adetini arttirma kismi
					fclose(_dosya);
					int adet;
					printf(" \t-Adet miktarini giriniz :");
					scanf("%d",&adet);
						if((_dosya=fopen("urunKayit.txt","r+")) == NULL){ // r+ :dosya okuma ve ekleme
					printf("Dosya olusturulamadi");
					
						}
						else{
						
							int i =0;
							while( !feof(_dosya) ){
							
 							fscanf(_dosya,"%s%s%d%d%d",urun[i].urunId, urun[i].urunAd, &urun[i].urunKategori, &urun[i].urunAdet,&urun[i].urunFiyat);
 							if(urun[i].urunKategori== 0) {
							break;
							}
							if(!strcmp(urunId,urun[i].urunId)) {  //iki char arrayin karsiliastirilmasi
								urun[i].urunAdet+= adet;  //adet arttirma
								//printf("%d",urun[i].urunAdet);
							}
							i++;
			 				}
			 				fclose(_dosya);
			 						if((_dosya=fopen("urunKayit.txt","w+")) == NULL){  //dosyayi temizleyip yeniden yazar
									printf("\nDosya olusturulamadi \n");
					
									}
								else{
									fprintf(_dosya,"");   //txt dosyasini temizlemek icin eklendi
									fclose(_dosya);
								}	
			 					
			 					if((_dosya=fopen("urunKayit.txt","a+")) == NULL){
									printf("\nDosya olusturulamadi \n");
									}
								else{
									int i =0 ;
								
									while(1) {  //sonsuz dongu elde eder
										if(urun[i].urunKategori ==0) {  //istenilen yere ulasildiginda whileyi durdurur
											break;
											}
										fprintf(_dosya,"%s %s %d %d %d\n",urun[i].urunId, urun[i].urunAd, urun[i].urunKategori, urun[i].urunAdet,urun[i].urunFiyat);
										i++;
										}
										fclose(_dosya);
									}
								}
					}

			 UrunGoruntule();
		}
    }
void UrunGoruntule() {  //case 4 urunleri sirasi ile goruntuler
		FILE *_dosya;
			
		if((_dosya=fopen("urunKayit.txt","r+")) == NULL) {
		printf("\nDosya olusturulamadi \n");
	}else {
		int i=0;
		
			printf("\n\t| %-12s| %-18s | %-10s | %-12s | %-12s |\n", " ID", "  AD", " KATEGORI", " ADET", " FIYAT"); //%-12s : tabloda degerleri hizalamayi saglar
			printf("\t******************************************************************************* \n");  //tablo duzenleme amacli
				while( !feof(_dosya) ){
			
 				fscanf(_dosya,"%s\t%s\t%d\t%d\t%d",urun[i].urunId, urun[i].urunAd, &urun[i].urunKategori, &urun[i].urunAdet,&urun[i].urunFiyat);
 			
	
 					
 					if(urun[i].urunKategori== 0) {
					break;		
					urunFonkCalis=1;			
				}
					printf("\t|%-12s | %-18s | %-10d | %-12d | %-12d |\n",urun[i].urunId, urun[i].urunAd, urun[i].urunKategori, urun[i].urunAdet,urun[i].urunFiyat);
					printf("\t------------------------------------------------------------------------------- \n");
					i++;
			 }	
			 	
			fclose(_dosya);
	}
}
void UrunleriDoldur() {   //dosyaadaki verileri urun arraylerine doldurur
	
		if(urunFonkCalis ==0) {  //arraylerin  bos oldugunu gosterir
				FILE *_dosya;
		if((_dosya=fopen("urunKayit.txt","r+")) == NULL) {
		printf("\nDosya olusturulamadi \n");
	}else { 
			int i =0;
			while( !feof(_dosya) ){
			
 				fscanf(_dosya,"%s%s%d%d%d",urun[i].urunId, urun[i].urunAd, &urun[i].urunKategori, &urun[i].urunAdet,&urun[i].urunFiyat);
 					if(urun[i].urunKategori== 0) {
					break;
				}
 			
				i++;
		
		}
		 }	
		 urunFonkCalis =1; // urun okuma gerceklestiyse 1 
	}
}
void MusterileriDolur() {   //dosyadaki musterileri arraye aktarir
		FILE *_dosya;
		if((_dosya=fopen("musterikayit.txt","r+")) == NULL) {
		printf("\nDosya olusturulamadi \n");
	}else {
		int i=0;
				while( !feof(_dosya) ){
 				fscanf(_dosya,"%s%s%s%d",musteriler[i].musteriAd,musteriler[i].musteriSoyad,musteriler[i].musteriNo, &musteriler[i].musteriId);
 					if(musteriler[i].musteriId ==0) {  //bittigini gosterir
					break;					
				}
				i++;
			 }	
			fclose(_dosya);
	}
}
void SatisYap() {  //case 5 satis islemi
	UrunleriDoldur();  //eger ekran acilir acilmaz direkt satis islemi gerceklestirilicese onlem amacli arraye bilgi doldurma amacli calistirilir
	FILE *_dosya;
	char urunId[10];  //gecici �d tutma
	int satilanAdet;  //gecici satilan adet tutma
	int odeme=0;     //gecici fiyat tutumu
	if((_dosya=fopen("satiskayit.txt","a+")) == NULL) {
		printf("\nDosya olusturulamadi \n");
	}else {
				int i =0;
				int gotoKontrol =0;  // urunun birden fazla yazla dosyaya yazilmasini engellemek icin kontrol 0=girmemis 1=olay gerceklesmis
				while( !feof(_dosya) ){
			
 				fscanf(_dosya,"%s%d%s%d",satislar[i].urunId, &satislar[i].musteriId, satislar[i].tarih, &satislar[i].adet);
 					if(urun[i].urunKategori== 0) {
					break;
				}				
				i++;
			 }
			 soru:
			 printf("\t-Urun ID girin:");          
			 scanf("%s",satislar[i].urunId);         //kullanindan satis bilgilerini almak icin
			 strcpy(urunId,satislar[i].urunId);          //sagdaki arrayin bilgilerini soldakine esitler sadece char arraylerinde kullanilir
			 if(urunBul(satislar[i].urunId)) {             //istenilen urunu arama listede varligini kontrol etme
			 	printf("\t-Musteri ID Girin:");
				 scanf("%d",&satislar[i].musteriId);
			 	if(musteriBul(satislar[i].musteriId)) {   //
			    	 printf(" \t-Tarih Girin :(tarih arasi nokta(.) koyun(bkz 02.05.2020) :"); //tarihte bosluk birakilirsa sistem coker nokta koy
			 		scanf("%s",satislar[i].tarih);
			 		printf(" \t-Adet Girin:");
			 		scanf("%d",&satislar[i].adet);
			 		satilanAdet = satislar[i].adet;  //gecici esitleme
			 		satis:    //gotodan sonra bir sonraki adim burasi olur
			 		if(gotoKontrol == 1) {    //fprintf i iki kere girmesini engellemek amaciyla
			 			if((_dosya=fopen("satiskayit.txt","a+")) == NULL) {
						 printf("Dosya olusturulamadi");
						 }
					 	else { 
	 					satislar[i].fiyat = odeme;  //atama
			 		 	fprintf(_dosya,"%s %d %s %d %d\n",satislar[i].urunId, satislar[i].musteriId, satislar[i].tarih, satislar[i].adet,satislar[i].fiyat);
			 		 	
			 		 	printf("\t\t --SATIS LISTESI--\n");
			 		 	printf(" \t |%-9s | %-11s | %-14s | %-9s | %-9s  |\n", "URUN ID", "MUSTERI ID","  TARIH", "  ADET", "  FIYAT" );  //degerler dusgun hizali gorunmesi amaciyla string ifade olarak tanimlandi
						 printf(" \t ********************************************************************** \n");
			 		 	printf(" \t |%-9s | %-11d | %-14s | %-9d | %-9d  |\n",satislar[i].urunId, satislar[i].musteriId, satislar[i].tarih, satislar[i].adet,satislar[i].fiyat);
			 			fclose(_dosya);
					}
				 }
				 else {
				 		fclose(_dosya);
				 }
					if((_dosya=fopen("urunKayit.txt","a+")) == NULL){
					printf("Dosya olusturulamadi");
					}
					else{
							int i =0;
							while( !feof(_dosya) ){
 							fscanf(_dosya,"%s%s%d%d%d",urun[i].urunId, urun[i].urunAd, &urun[i].urunKategori, &urun[i].urunAdet,&urun[i].urunFiyat);
 							if(urun[i].urunKategori== 0) {
							break;
							}
							if(!strcmp(urunId,urun[i].urunId)) {   //iki char arrayini karsilastirir ayni ise 0 doner
								urun[i].urunAdet-= satilanAdet;
								//printf("%d",urun[i].urunAdet);
								odeme = urun[i].urunFiyat;
								
								if(gotoKontrol ==0) {
									gotoKontrol=1;
									goto satis;
								}
								
							}
							i++;
			 				}
			 				fclose(_dosya);
			 				if((_dosya=fopen("urunKayit.txt","w+")) == NULL){
							printf("Dosya olusturulamadi");
		
							}else {
								fprintf(_dosya,"");
									fclose(_dosya);
							}
							if((_dosya=fopen("urunKayit.txt","a+")) == NULL){
							printf("Dosya olusturulamadi");
		
							}else {
								int i =0;
								while(1) {
									if(urun[i].urunKategori ==0) {
										break;
										}
									if(urun[i].urunAdet <10) { //urunun stok miktarini kontol eder 10 un asagisina dusunce uyarir
											printf("\n \t UYARI!! %s  ID'li urunun stogu 10'un altina dusmustur.\n",urun[i].urunId);  
										}
									fprintf(_dosya,"%s %s %d %d %d\n",urun[i].urunId, urun[i].urunAd, urun[i].urunKategori, urun[i].urunAdet,urun[i].urunFiyat);
									i++;
								}
								fclose(_dosya);
								UrunGoruntule();
							}
							
					}
			    }
			 else {
			 	printf("/t musteri bulunamadi.. tekrar deneyiniz \n");
			 	goto soru;   //musteri bulunamaz ise sorma islemini tekrarlatmak icin
			 }
			 }
			 else {
			 		printf("/t urun bulunamadi.. tekrar deneyiniz \n");  //urun bulunamazsa tekrar denemek icin
			 	goto soru;   
			 }
	 }
}
void SatisGoruntule(){   //case 6 verilen tarihe gore urunlerin tumunu goruntuleme
	 	FILE *_dosya;
		 char tarih[20];
		 int fiyat[100];  //gecici degerler
		 int adet[100];
		 int total=0;
		 satisBosalt(satislar); //satislar arrayini temizler
		 printf(" \t -bir tarih girin (tarih arasi nokta(.) koyun (bkz 02.05.2020))  :");
	 	scanf("%s", tarih);
	 	printf("\n\n");
	 	printf("\t\t --SATIS LISTES�--\n");
			printf(" \t |%-9s | %-11s | %-14s | %-9s | %-9s  |\n", "URUN ID", "MUSTERI ID","  TARIH", "  ADET", "  FIYAT" );
			printf(" \t ********************************************************************** \n");
	   	if((_dosya=fopen("satiskayit.txt","a+")) == NULL) {
		 printf("\nDosya olusturulamadi \n");
			}else {
				int i =0, k=0;
				while( !feof(_dosya) ){
			
 				fscanf(_dosya,"%s%d%s%d%d",satislar[i].urunId, &satislar[i].musteriId, satislar[i].tarih, &satislar[i].adet,&satislar[i].fiyat);
 					if(satislar[i].adet == 0) {
 						
				 	break;
				}				
			
				if(!strcmp(satislar[i].tarih,tarih)){  //girilen tarih ile dosyadaki tarih esit mi kontrol				
					
				 	if(satislar[i].fiyat!=0){  //fiyat 0 dan farkli ise calisir
					 
						 printf(" \t |%-9s | %-11d | %-14s | %-9d | %-9d  |\n",satislar[i].urunId, satislar[i].musteriId, satislar[i].tarih, satislar[i].adet, satislar[i].fiyat);	
					 	printf("   \t -------------------------------------------------------------------- \n");
					 	fiyat[k]=satislar[i].fiyat;  //atama 
				 		adet[k]=satislar[i].adet;
				 		total +=fiyat[k]*adet[k];  //tarih icerisindeki tum alinan urunleri fiyat ve kac tane aldigi carpilarak totale eklenir  ve yazdirilir
				 		k++;
				}
				}
				i++;
			 }
			 	printf(" \n \n \tToplam Satis : %d \n \t" , total);
			 	int j;
			 	printf("\n \n \t (");
			 	for(j=0; j<50 ;j++){
			 		if(adet[j]!=0 && fiyat[j]!=0) {  //urunler bitene kadar islem yapmasini saglar
					
					 
			 		printf(" + %d * %d " , adet[j], fiyat[j]);  //totaldeki islemlerin tamamini gosterir
			     	}
			     	else{
			     		break;
					 }
				 }
				printf(" = %d )\n " ,total) ;  //total yazdirma
            }
            	 
	fclose(_dosya);	
				 	
}
void satisBosalt(struct satis satislar[100]) {  //parametre olarak alinan satis arrayini temizler
	int i =0;
	while(1) {
		if(satislar[i].fiyat == 0) {
			break;
		}
		satislar[i].adet =0;
		satislar[i].fiyat =0;
		satislar[i].musteriId =0;
		strcpy(satislar[i].tarih,"") ;  //bu islemi int e 0 string ifadelere bosluk vererek gerceklestirir
		strcpy(satislar[i].urunId,"") ;
		i++;
	}
}
int urunBul(char urunId[]) {   //satista aranan urunu parametre alan bu fonksiyon 1 veya 0 donerek kontrol gerceklestirir
		
		int flag =0;
		int i = 0;
		char str[80];
		char*token;
		const char s[2] = "\\";    //dosyadan gelen bilgi / ile birden fazla 0 icerdigi icin esitleme saglanamiyodu bunun icin bu degiskeni tanimlayip 
		while(flag !=1) {           //gordugumuz ilk / isaretinden sonrasini atarak karsilastirma saglandi
			strcpy(str,urun[i].urunId);
			token = strtok(str, "\\");  //bu ayirma islemini burasi saglar / isaretine kadar gordugu degeri alip saklar
			if(urun[i].urunFiyat != 0) {
				if(!strcmp(urunId,token)) {  //bulunan deger ile aranan ifade karsilastirma
				flag = 1;
				break;
			}
			}
			if(urun[i].urunAdet == 0 &&urun[i].urunFiyat ==0 ) {
				break;
			}
			
			i++;
		}
	return flag;
}
int musteriBul(int id) {   //satista urunu alan kisi parametre alinarak dosya icerisinde olup olmadiginin kntroledildigi yer
	MusterileriDolur();     //butun bilgileri tazeler
	int flag = 0;
	int i =0 ;
	while(flag !=1) {      
		if(id==musteriler[i].musteriId) { //karsilastirma
				flag = 1;
				break;
			
			}
			i++;
	}
	return flag;
}


int main(int argc, char *argv[]) {
	
		system("color F5");   //consol ekranininin farkli konseptte renkli gorunmesini saglar
		SuperMarket.Supermarketadi[0][50] = "BILGEN";
		int k,l;
			 SuperMarket.Kitalar[0][50] = "Asya";
			 SuperMarket.Kitalar[1][50] = "Avrupa";
			 SuperMarket.Kitalar[2][50] = "Kuzey Amerika";		
			 SuperMarket.Ulkeler[0][50] = "Cin,Kore";            //structta tanimlanan degerleri mainde kontrol saglandi
			 SuperMarket.Ulkeler[1][50] = "Turkiye,Almanya";
			 SuperMarket.Ulkeler[2][50] = "Kanada";
			 SuperMarket.Sehirler[0][50] = "Pekin,Seul";
			 SuperMarket.Sehirler[1][50] = "Kreusberg,Izmir,�stanbul,Eskisehir";
			 SuperMarket.Sehirler[2][50] = "Oltava";
			 SuperMarket.Turler[0][50] = "Giyim";
			 SuperMarket.Turler[1][50] = "Mobilya";
			 SuperMarket.Turler[2][50] = "Yiyecek";
			 SuperMarket.Turler[3][50] = "Elektronik";
			 SuperMarket.Turler[4][50] = "Temizlik";	
			 SuperMarket.magazalar[0][50] = "magaza1";
			 SuperMarket.magazalar[1][50] = "magaza2";        
			 SuperMarket.magazalar[2][50] = "magaza3";
			 SuperMarket.magazalar[3][50] = "magaza4";
			 SuperMarket.magazalar[4][50] = "magaza5";        
			 SuperMarket.magazalar[5][50] = "magaza6";
			 SuperMarket.magazalar[6][50] = "magaza7";
			 SuperMarket.magazalar[7][50] = "magaza8";        
			 SuperMarket.magazalar[8][50] = "magaza9";
			 SuperMarket.magazalar[9][50] = "magaza10";
			 SuperMarket.magazalar[10][50] = "magaza11";        
			 SuperMarket.magazalar[11][50] = "magaza12";
			 SuperMarket.magazalar[12][50] = "magaza13";
			 SuperMarket.magazalar[13][50] = "magaza14";        
			 SuperMarket.magazalar[14][50] = "magaza15";		
			 SuperMarket.Calisanlar[0][50] = "M1-Emre";
			 SuperMarket.Calisanlar[1][50] = "M2-Selin";
			 SuperMarket.Calisanlar[2][50] = "M3-Ceren";
			 SuperMarket.Calisanlar[3][50] = "M4-Mustafa";
			 SuperMarket.Calisanlar[4][50] = "M5-Ali";
			 SuperMarket.Calisanlar[5][50] = "M6-Zehra";
			 SuperMarket.Calisanlar[6][50] = "M7-Eda";
			 SuperMarket.Calisanlar[7][50] = "M8-Osman";
			 SuperMarket.Calisanlar[8][50] = "M9-Fulya";
			 SuperMarket.Calisanlar[9][50] = "M10-Doruk";
			 SuperMarket.Calisanlar[10][50] = "M11-Nisa";
			 SuperMarket.Calisanlar[11][50] = "M12-Bar�s";
			 SuperMarket.Calisanlar[12][50] = "M13-�rem";
			 SuperMarket.Calisanlar[13][50] = "M14-Mert";
			 SuperMarket.Calisanlar[14][50] = "M15-Deniz";
					
		
		int menuSecim;
		int dongu=0;
		while(dongu==0){
			menu();
			printf("\n\tSeciminizi giriniz:  ");   //MENU icerisinden yapmak istenilen isleme gore gerekli parametrelere atanmasini saglar
   		 	scanf("%d", &menuSecim);
   		 	printf("\n\n");
   		 	switch(menuSecim){
    	
				case 1:
					musteriEkle();
					system("Pause");	//ekran gecislerini denetlemek icin
				    break;
				case 2:	
				 	musteriGoruntule(); 
					 system("Pause");	
			    	break;
				case 3:				
					UrunEkle();
					system("Pause");
     			break;
		
				case 4:					
					UrunGoruntule();
					system("Pause");	
	    		break;
				case 5:
					SatisYap();
					system("Pause");
				break;
				case 6:	
					SatisGoruntule();
					system("Pause");		
				break;	
				case 0:
					printf("\t\tIyi gunler dileriz..");
					return 0;
				default:
				printf("\tMalesef kategori disi secim yaptiniz ...");
	    	}
  		 }
        	return 0;
	}
